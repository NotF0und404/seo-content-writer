# SEO 內容簡報模板

## 1. 基本需求

| 欄位 | 內容 |
|---|---|
| Topic | [主題] |
| Primary Keyword | [主關鍵詞] |
| Secondary Keywords | [2–5 個相關詞] |
| Target Market / Language | [市場與語言] |
| Content Type | [blog / guide / landing page / comparison / review / service page] |
| Target Audience | [目標讀者] |
| Search Intent | [informational / commercial / transactional / navigational] |
| Funnel Stage | [TOFU / MOFU / BOFU] |
| Target Word Count | [字數] |
| Tone | [專業 / 技術 / 友好 / 中立] |
| CTA Goal | [低壓力行動目標] |
| Compliance Notes | [不得誇大、不得誘導、YMYL 風險] |

## 2. SERP Analysis

| SERP 項目 | 觀察 |
|---|---|
| Top Results Format | [文章、工具頁、列表、比較頁、產品頁等] |
| Common Title Angles | [常見標題角度] |
| Common Sections | [排名頁常見 H2/H3] |
| SERP Features | [Featured snippet、PAA、video、image、news 等] |
| Average Depth Proxy | [字數、段落數、表格/FAQ/圖表需求] |
| Content Gap | [競品缺口與本篇差異化角度] |
| Risk Level | [Low / Medium / High；是否 YMYL] |

## 3. Keyword Map

| 類型 | 關鍵詞 | 使用位置 | 注意事項 |
|---|---|---|---|
| Primary | [keyword] | Title、H1、前 100 字、結論 | 自然使用，不堆砌 |
| Secondary | [keyword] | H2/H3、正文 | 匹配段落主題 |
| Long-tail | [question/query] | FAQ 或 H2/H3 | 用 40–60 字直接回答 |
| Related / Entity | [term] | 正文與表格 | 提升語義完整度 |

## 4. Title Optimization

| 選項 | Title | 長度 | 關鍵詞位置 | 評估 |
|---|---|---:|---|---|
| 1 | [Title option 1] | [X] | [front/middle] | [匹配意圖與點擊理由] |
| 2 | [Title option 2] | [X] | [front/middle] | [匹配意圖與點擊理由] |
| 3 | [Title option 3] | [X] | [front/middle] | [匹配意圖與點擊理由] |

**Recommended Title**: [推薦標題與理由]

## 5. Meta Description

**Meta Description**: [150–160 英文字符或中文約 70–90 字，包含主關鍵詞、具體價值、低壓力 CTA]

| 元素 | 狀態 | 說明 |
|---|---|---|
| Primary Keyword | [Pass/Warning/Fail] | [說明] |
| Value Proposition | [Pass/Warning/Fail] | [說明] |
| Low-pressure CTA | [Pass/Warning/Fail] | [不得誇大或誘導] |

## 6. Featured Snippet Plan

| 查詢/問題 | Snippet 類型 | 回答格式 |
|---|---|---|
| [query] | Definition / List / Table / How-to / FAQ | [40–60 字答案、列表或表格] |

## 7. Evidence Plan

| Claim / Section | Required Evidence | Preferred Source | Status |
|---|---|---|---|
| [claim] | [數據、定義、政策、風險提示] | [官方/政府/學術/平台/行業報告] | [待查/已找到] |

## 8. Link Plan

| 類型 | Anchor Text | Target | Reason |
|---|---|---|---|
| Internal | [anchor] | [URL 或建議頁面類型] | [關聯理由] |
| External | [anchor] | [權威來源 URL] | [支持哪個 claim] |

## 9. Proposed Outline

# [H1]

## [H2: Direct Answer / Key Takeaways]

## [H2]

### [H3]

## [H2: Data Table / Comparison]

## [H2: Risks / Limitations]

## [H2: FAQ]

## [H2: Conclusion]
