# [H1: Primary Keyword + Search Intent]

> **摘要 / Key Takeaways**：用 3–5 句說清本文回答什麼問題、適合誰閱讀、核心結論是什麼。若涉及 YMYL，先加入必要風險提示與資料限制。

## Table of Contents

- [本文適合誰](#本文適合誰)
- [直接答案](#直接答案)
- [背景與定義](#背景與定義)
- [核心數據與比較](#核心數據與比較)
- [實操步驟或判斷框架](#實操步驟或判斷框架)
- [風險、限制與注意事項](#風險限制與注意事項)
- [常見問題](#常見問題)
- [結論](#結論)
- [References](#references)

## 本文適合誰

本文適合 [目標讀者]，尤其是正在搜尋「[Primary Keyword]」並希望 [搜尋意圖] 的使用者。本文不適合希望獲得保證性結論、投資承諾、醫療診斷或法律意見的讀者。

## 直接答案

用 100–150 字直接回答主查詢。第一段自然包含 primary keyword，避免誇大語與無來源斷言。若存在不確定性，明確說明限制。

## 背景與定義

解釋核心概念、適用範圍與必要上下文。所有定義、政策或數據性陳述都應加引用，例如 `[1]`。

## 核心數據與比較

| 指標 / 方案 | 數據或特徵 | 來源 | 解讀 |
|---|---|---|---|
| [指標] | [數據 + 單位] | [來源編號] | [保守解讀] |

正文應說明資料年份、樣本、來源限制與不能推導的結論。不得把相關性寫成因果性。

## 實操步驟或判斷框架

### [H3: 步驟 1]

用清楚、可操作的方式說明第一步。每段 3–5 句，必要時加入表格、清單或示例。

### [H3: 步驟 2]

補充下一步，並自然覆蓋 secondary keyword 或 long-tail keyword。

## Featured Snippet 區塊

| 問題 | 精簡答案 |
|---|---|
| [問題型長尾詞] | [40–60 字直接答案，避免絕對化] |

## 風險、限制與注意事項

說明本主題的限制、適用邊界、資料不足處與使用者需要自行判斷的部分。YMYL 內容必須加入「本文僅供資訊參考，不構成專業建議」等聲明。

## 內外鏈建議

| 類型 | Anchor Text | Target | Reason |
|---|---|---|---|
| Internal | [anchor] | [URL 或建議頁面類型] | [關聯理由] |
| External | [anchor] | [權威來源 URL] | [支持哪個 claim] |

## 常見問題

### [FAQ 1]

用 40–60 字回答，直接、可引用、避免誇大。若答案依賴外部資料，加入引用。

### [FAQ 2]

用 40–60 字回答，並自然覆蓋相關長尾詞。

### [FAQ 3]

用 40–60 字回答，補足使用者在 SERP/PAA 中常見的疑問。

## 結論

回到開頭問題，總結最重要的 2–3 個判斷，給出低壓力且符合搜尋意圖的下一步。不得使用高壓銷售、誇大收益或保證性語句。

## On-page SEO Self-Check

| Factor | Status | Notes |
|---|---|---|
| Title includes primary keyword | [Pass/Warning/Fail] | [說明] |
| Meta description is specific and compliant | [Pass/Warning/Fail] | [說明] |
| H1 is unique and intent-matched | [Pass/Warning/Fail] | [說明] |
| Primary keyword appears naturally in first 100 words | [Pass/Warning/Fail] | [說明] |
| H2/H3 cover secondary and long-tail keywords | [Pass/Warning/Fail] | [說明] |
| Internal links suggested | [Pass/Warning/Fail] | [說明] |
| External authoritative citations included | [Pass/Warning/Fail] | [說明] |
| FAQ has at least 3 questions | [Pass/Warning/Fail] | [說明] |
| Readability matches audience | [Pass/Warning/Fail] | [說明] |
| Depth matches SERP intent | [Pass/Warning/Fail] | [說明] |

**Overall SEO Score**: [X]/10

## References

[1]: [Source Title](https://example.com)  
[2]: [Source Title](https://example.com)  
[3]: [Source Title](https://example.com)
