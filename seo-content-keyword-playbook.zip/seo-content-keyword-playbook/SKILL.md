---
name: seo-content-keyword-playbook
description: "SEO 內容方向、SERP 分析、關鍵詞拉取、長尾詞擴展、SEO Content Writer 與合規文章生成流程。Use for: 規劃內容集群、挖掘長尾關鍵詞、分析搜尋結果意圖、生成 Title/Meta、設計 H1-H6 結構、優化 Featured Snippet、引用權威資料、生成符合 Google E-E-A-T 且不誇大不誘導的資料化 SEO 文章。"
---

# SEO Content Keyword Playbook

使用本技能時，將自己定位為 **SEO 內容策略負責人與 SEO Content Writer**。目標不是只列關鍵詞或直接產文，而是建立一條可驗證的內容生產鏈路：**種子詞 → 長尾詞 → SERP 意圖 → 權威資料 → 內容簡報 → Title/Meta → 資料化文章 → Featured Snippet 優化 → EEAT 與風險審核**。

## 何時使用

當使用者要求 SEO 內容方向、關鍵詞拉取、長尾詞擴展、博客文章、落地頁、產品頁、服務頁、How-to 指南、比較文、評測文、支柱內容或內容集群規劃時，使用本技能。若任務涉及金融、投資、醫療、法律、安全等 YMYL 主題，必須啟用更嚴格的權威引用、風險提示與保守表述。

## 必要輸入

開始前盡量取得以下資料。若資料不足，仍可先產出第一版，但必須標記假設、待確認資料與不可驗證部分。

| 輸入 | 用途 | 缺失時的處理 |
|---|---|---|
| 目標網站、產品或業務類型 | 判斷內容方向與轉化目標 | 先以通用 SEO 內容策略處理 |
| Primary Keyword / 種子詞 | 拉取相關詞與長尾詞 | 從產品、服務、受眾痛點推導候選詞 |
| Secondary Keywords | 建立語義覆蓋與 H2/H3 結構 | 由 SERP、搜尋建議與 PAA 補足 |
| 目標市場與語言 | 決定本地化、SERP 與引用來源 | 預設以使用者語言處理 |
| Content Type | 決定文章、落地頁、指南或比較文模板 | 依 SERP 主流格式判斷 |
| Target Audience | 調整深度、語氣與例子 | 明確標記假設受眾 |
| Search Intent | 匹配資訊、商業、交易或導航意圖 | 由 SERP 推斷 |
| Target Word Count | 控制深度與引用密度 | 實質文章建議不少於 800 字 |
| Tone / CTA Goal | 決定語氣與低壓力轉化 | 不得誇大、不做高壓誘導 |
| 競品或 SERP 對標頁 | 分析意圖、缺口與結構 | 使用公開搜尋結果替代 |
| 合規限制 | 避免誇大、誘導、投資承諾 | 預設採取保守、事實導向寫法 |

## 工作流程

### 1. 定義內容方向與主題集群

先把業務拆成主題集群，而不是直接堆文章。每個主題集群都必須有目標受眾、搜尋意圖、漏斗階段、可支撐資料來源與轉化頁。

| 欄位 | 要求 |
|---|---|
| Topic Cluster | 例如新手指南、產品比較、問題解決、數據解讀、風險教育 |
| Search Intent | Informational、Commercial、Transactional、Navigational |
| Funnel Stage | TOFU、MOFU、BOFU |
| Conversion Target | 註冊、試用、產品頁、交易頁、諮詢、下載或訂閱 |
| Evidence Need | 必須引用的官方、學術、政府、平台或行業資料 |

### 2. 拉取與擴展長尾關鍵詞

必須從多來源擴展長尾詞，避免只依賴單一工具或 AI 猜詞。可使用搜尋建議、People Also Ask、Related Searches、競品標題、站內搜尋資料、Google Search Console、Keyword Planner、Google Trends、公開論壇與問答社群。

輸出關鍵詞表時至少包含：**keyword、language、market、intent、funnel_stage、difficulty_proxy、content_type、serp_features、evidence_need、priority、notes**。若沒有搜尋量工具，使用「意圖強度、商業價值、內容缺口、可證據化程度、轉化距離」作為優先級代理指標，並標記資料來源是自動拉取、使用者提供或估算。

### 3. 做 SERP 分析後再寫內容

每個目標長尾詞都要先分析 SERP，而不是直接產文。觀察排名頁類型、標題角度、內容深度、SERP features、常見問題、是否需要表格、圖表、數據、工具或案例。

| SERP 項目 | 分析要求 |
|---|---|
| Top Results | 記錄前 5–10 個結果的頁面類型、標題、角度與缺口 |
| Search Intent | 判斷使用者想學習、比較、購買、解決問題或查資料 |
| SERP Features | 記錄 PAA、featured snippet、video、image、local pack、news 等 |
| Common Sections | 彙整排名頁常見 H2/H3、FAQ、表格、清單與工具 |
| Content Gap | 找出競品沒講清楚、資料過時、缺少引用或缺少實操步驟之處 |
| Risk Level | 標記是否涉及金融、醫療、法律、安全、投資或其他 YMYL 題材 |

### 4. 建立 Keyword Map 與 Featured Snippet 策略

將 Primary Keyword 放在 Title、H1、前 100 字、至少一個 H2 或自然變體、結論中。Secondary Keywords 可用於 H2、H3 與正文段落。問題型長尾詞優先做成 FAQ 或 H2/H3。LSI/Related Terms 只可自然融入，不得堆砌。

針對 SERP 特徵設計 Snippet 格式。定義型查詢用 40–60 字直接答案；步驟型查詢用有序列表；比較型查詢用表格；清單型查詢用精簡列表；數據型查詢用表格與引用。

### 5. 權威資料與引用規則

文章不得只靠模型生成。每篇文章至少引用 3 個可信來源；YMYL 題材建議引用 5 個以上。優先使用官方文件、政府機構、監管機構、學術研究、標準組織、平台官方數據、知名行業報告與一手資料。

所有 factual claim、數據、趨勢判斷、定義、政策說法與風險提示都必須加引用。引用格式使用 Markdown 參考式連結，並在 References 區列出來源標題與 URL。不得捏造來源、不得引用無法訪問或與內容無關的來源。

### 6. 生成 Title、Meta 與內容簡報

寫正文前先產出內容簡報。Title 應包含 primary keyword，優先控制在 60 個英文字符或中文約 30 字以內，且必須匹配搜尋意圖。Meta Description 建議 150–160 個英文字符或中文約 70–90 字，包含關鍵詞、具體價值與低壓力 CTA；不得用「保證、一定、最強、穩賺、無風險」等誇大語。

預設使用 `/home/ubuntu/skills/seo-content-keyword-playbook/templates/article_brief_template.md`。

### 7. 生成資料化 SEO 文章

文章必須包含：H1、Table of Contents、Key Takeaways 或摘要框、本文適用對象、直接答案、定義或背景、核心數據表、步驟或比較、風險/限制、FAQ、結論、References。標題層級必須 H1 → H2 → H3，不得跳級；段落建議 3–5 句；每個區塊只處理一個主題；避免填充文字。

預設使用 `/home/ubuntu/skills/seo-content-keyword-playbook/templates/article_template.md`。

### 8. 內外鏈與 On-page SEO 優化

生成文章時提供 2–5 個內鏈建議與 2–3 個權威外鏈建議。內鏈需說明 anchor text、目標 URL 或建議頁面類型、關聯理由；外鏈需說明支持哪個 claim。若使用者未提供網站結構，可先給「建議內鏈頁面」而非虛構 URL。

最後以 10 項 On-page SEO 因子打分：Title、Meta Description、H1、Keyword Placement、H2/H3、Internal Links、External Links、FAQ、Readability、Word Count / Depth。總分滿分 10，低於 8 分應先修改再交付。

### 9. 合規與 EEAT 審核

交付前必須執行品質檢查。不得誇大收益、保證結果、誘導用戶做高風險決策、隱瞞限制或把不確定內容寫成確定事實。對金融、投資、健康、法律、安全等 YMYL 題材，必須加入風險提示與「非專業建議」類聲明，並優先引用權威來源。

使用 `/home/ubuntu/skills/seo-content-keyword-playbook/references/eeat_quality_checklist.md` 進行審核。若文章未通過檢查，先修改再交付。

## 交付格式

標準交付包含四份內容：**關鍵詞機會表、SERP/內容簡報、文章正文、SEO/EEAT 自檢**。若使用者只要求其中一項，可以縮小交付，但不能跳過必要的權威引用與合規審核。

| 交付物 | 格式 | 必須包含 |
|---|---|---|
| 關鍵詞機會表 | Markdown 或 CSV | 長尾詞、意圖、SERP features、優先級、內容類型、資料來源 |
| SERP/內容簡報 | Markdown | SERP 摘要、內容缺口、Keyword Map、Title/Meta、H2/H3 大綱 |
| 文章正文 | Markdown | 引用、資料表、TOC、FAQ、風險限制、References |
| SEO/EEAT 自檢 | Markdown 表格 | 10 項 SEO 分數、CORE-EEAT 狀態、需修正項 |

## 品質標準

內容必須以使用者需求為中心，具備可驗證資料、清楚結構與保守表述。不得生成「最佳、保證、穩賺、一定、無風險」等絕對化或誘導性表述，除非有權威來源支持且語境允許。若資料不足，要明確寫出「目前公開資料不足以證明」或「需要進一步驗證」。Keyword density 只能作為粗略參考，不能為了 1–2% 密度破壞自然語言；優先追求語義覆蓋、意圖匹配與證據充足。
